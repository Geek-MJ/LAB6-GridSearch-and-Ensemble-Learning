Blackout_PowerGraph_19000.csv

Source: PowerGraph, https://figshare.com/articles/dataset/PowerGraph/22820534
Source archive: dataset_cascades.zip (Figshare file 50083479).
Subset: IEEE-24, originally 21,500 simulated scenarios.
This file contains 19,000 additional original scenario records. Source scenario indices do not overlap those used in Blackout_PowerGraph_1000.csv; that previous extraction was reconstructed and verified exactly before selection.
Original source records may have identical feature values; these existing repetitions are preserved. This is an additional dataset, not an independent held-out test set.
The 225-column schema is identical to the previously provided 1,000-row CSV.
As in that CSV, original MATLAB matrices are flattened into 224 named input columns. Numeric values use 10 significant digits.
Target blackout is 1 when source demand-not-served is greater than zero, otherwise 0. This matches the source binary labels. It does not imply a total national blackout or necessarily an additional cascade.
Simulated data, not historical blackout observations.
The target severity, regression output and explanation labels are not included as input features.
Source feature values retain the source preprocessing; do not interpret them as raw physical units without checking the authors' documentation.
Proportional sampling by target from the remaining source records, random seed 2026.
